//
//  VKPlayer.h
//  VideoKitDemo
//
//  Created by Single on 16/6/28.
//  Copyright © 2016年 single. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VKPlayerDefine.h"

@interface VKPlayer : NSObject

+ (instancetype)playerWithURL:(NSURL *)contentURL;
+ (instancetype)playerWithURL:(NSURL *)contentURL videoType:(VKVideoType)videoType;

@property (nonatomic, copy) NSString * identifier;      // default is VKPlayerDefaultIdentifier
@property (nonatomic, copy, readonly) NSURL * contentURL;
@property (nonatomic, assign, readonly) VKVideoType videoType;
@property (nonatomic, assign, readonly) VKPlayerState state;
@property (nonatomic, strong, readonly) UIView * view;      // graphics view

@property (nonatomic, assign, readonly) NSTimeInterval progress;
@property (nonatomic, assign, readonly) NSTimeInterval duration;
@property (nonatomic, assign, readonly) NSTimeInterval playableTime;
@property (nonatomic, assign) NSTimeInterval playableBufferInterval;    // default is 2s

- (void)replaceVideoWithURL:(NSURL *)contentURL;
- (void)replaceVideoWithURL:(NSURL *)contentURL videoType:(VKVideoType)videoType;

- (void)play;
- (void)pause;
- (void)seekToTime:(NSTimeInterval)time;

- (void)setViewTapBlock:(void(^)())block;   // view tap action

@end

#import "VKPlayer+Extsion.h"