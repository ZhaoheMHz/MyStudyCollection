//
//  VKPlayerDefine.h
//  VideoKitDemo
//
//  Created by Single on 16/8/15.
//  Copyright © 2016年 single. All rights reserved.
//

#import <Foundation/Foundation.h>

static NSString * const VKPlayerDefaultIdentifier = @"1000";

// video type
typedef NS_ENUM(NSUInteger, VKVideoType) {
    VKVideoTypeNormal,  // normal
    VKVideoTypeVR,      // virtual reality
};

// player state
typedef NS_ENUM(NSUInteger, VKPlayerState) {
    VKPlayerStateNone = 0,          // none
    VKPlayerStateBuffering = 1,     // buffering
    VKPlayerStateReadyToPlay = 2,   // ready to play
    VKPlayerStatePlaying = 3,       // playing
    VKPlayerStateSuspend = 4,       // pause
    VKPlayerStateFinished = 5,      // finished
    VKPlayerStateFailed = 6,        // failed
};

// notification name
static NSString * const VKPlayerErrorName = @"VKPlayerErrorName";                   // player error
static NSString * const VKPlayerStateChangeName = @"VKPlayerStateChangeName";     // player state change
static NSString * const VKPlayerProgressChangeName = @"VKPlayerProgressChangeName";  // player play progress change
static NSString * const VKPlayerPlayableChangeName = @"VKPlayerPlayableChangeName";   // player playable progress change

// notification userinfo key
// all
static NSString * const VKPlayerIdentifierKey = @"identifier";
// error
static NSString * const VKPlayerErrorMessageKey = @"message";
static NSString * const VKPlayerErrorCodeKey = @"code";
// state
static NSString * const VKPlayerStatePreviousKey = @"previous";
static NSString * const VKPlayerStateCurrentKey = @"current";
// progress
static NSString * const VKPlayerProgressPercentKey = @"percent";
static NSString * const VKPlayerProgressCurrentKey = @"current";
static NSString * const VKPlayerProgressTotalKey = @"total";
// playable
static NSString * const VKPlayerPlayablePercentKey = @"percent";
static NSString * const VKPlayerPlayableCurrentKey = @"current";
static NSString * const VKPlayerPlayableTotalKey = @"total";
