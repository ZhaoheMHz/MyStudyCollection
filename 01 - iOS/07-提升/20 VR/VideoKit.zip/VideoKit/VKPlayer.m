//
//  VKPlayer.m
//  VideoKitDemo
//
//  Created by Single on 16/6/28.
//  Copyright © 2016年 single. All rights reserved.
//

#import "VKPlayer.h"
#import "VKNotification.h"
#import "VKAVPlayer.h"

#define kVKVideoTypeError 1900

typedef NS_ENUM(NSUInteger, VKPlayerType) {
    VKPlayerTypeUnknown,    // unsupport video type
    VKPlayerTypeAVPlayer,   // normal or vr video
};

@interface VKPlayer ()

@property (nonatomic, copy) void(^playerViewTapAction)();
@property (nonatomic, assign, readonly) VKPlayerType playerType;
@property (nonatomic, strong) VKAVPlayer * avPlayer;

@end

@implementation VKPlayer

@synthesize view = _view;

+ (instancetype)playerWithURL:(NSURL *)contentURL
{
    return [[self alloc] initWithURL:contentURL videoType:VKVideoTypeNormal];
}

+ (instancetype)playerWithURL:(NSURL *)contentURL videoType:(VKVideoType)videoType
{
    return [[self alloc] initWithURL:contentURL videoType:videoType];
}

- (instancetype)initWithURL:(NSURL *)contentURL
{
    return [self initWithURL:contentURL videoType:VKVideoTypeNormal];
}

- (instancetype)initWithURL:(NSURL *)contentURL videoType:(VKVideoType)videoType
{
    if (self = [super init]) {
        self.contentURL = contentURL;
        self.videoType = videoType;
        self.identifier = VKPlayerDefaultIdentifier;
        [self setupPlayer];
    }
    return self;
}

- (instancetype)init
{
    if (self = [super init]) {
        self.contentURL = nil;
        self.videoType = kVKVideoTypeError;
        self.identifier = VKPlayerDefaultIdentifier;
    }
    return self;
}

- (void)replaceVideoWithURL:(NSURL *)contentURL
{
    [self replaceVideoWithURL:contentURL videoType:VKVideoTypeNormal];
}

- (void)replaceVideoWithURL:(NSURL *)contentURL videoType:(VKVideoType)videoType
{
    VKPlayerType beforePlayerType = self.playerType;
    self.contentURL = contentURL;
    self.videoType = videoType;
    
    if (beforePlayerType == self.playerType == VKPlayerTypeAVPlayer)
    {
        // VKAVPlayer
        [self.avPlayer replaceVideoWithURL:contentURL videoType:videoType];
    }
    else
    {
        [self setupPlayer];
    }
}

- (VKPlayerState)state
{
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            return self.avPlayer.state;
        }
        case VKPlayerTypeUnknown:
        {
            return VKPlayerStateFailed;
        }
    }
}

- (void)play
{
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            [self.avPlayer play];
        }
            break;
        case VKPlayerTypeUnknown:
        {
            
        }
            break;
    }
}

- (void)pause
{
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            [self.avPlayer pause];
        }
            break;
        case VKPlayerTypeUnknown:
        {
            
        }
            break;
    }
}

- (void)seekToTime:(NSTimeInterval)time
{
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            [self.avPlayer seekToTime:time];
        }
            break;
        case VKPlayerTypeUnknown:
        {
            
        }
            break;
    }
}

- (NSTimeInterval)progress
{
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            return self.avPlayer.progress;
        }
        case VKPlayerTypeUnknown:
        {
            return 0;
        }
    }
}

- (NSTimeInterval)duration
{
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            return self.avPlayer.duration;
        }
        case VKPlayerTypeUnknown:
        {
            return 0;
        }
    }
}

- (NSTimeInterval)playableTime
{
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            return self.avPlayer.playableTime;
        }
        case VKPlayerTypeUnknown:
        {
            return 0;
        }
    }
}

- (NSTimeInterval)playableBufferInterval
{
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            return self.avPlayer.playableBufferInterval;
        }
        case VKPlayerTypeUnknown:
        {
            return 0;
        }
    }
}

- (void)setPlayableBufferInterval:(NSTimeInterval)playableBufferInterval
{
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            self.avPlayer.playableBufferInterval = playableBufferInterval;
        }
            break;
        case VKPlayerTypeUnknown:
        {
            
        }
            break;
    }
}

- (void)setContentURL:(NSURL *)contentURL
{
    _contentURL = contentURL;
}

- (void)setVideoType:(VKVideoType)videoType
{
    switch (videoType) {
        case VKVideoTypeNormal:
        case VKVideoTypeVR:
        {
            _videoType = videoType;
        }
            break;
        default:
        {
            _videoType = kVKVideoTypeError;
        }
            break;
    }
}

- (void)setIdentifier:(NSString *)identifier
{
    _identifier = identifier;
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            self.avPlayer.identifier = identifier;
        }
            break;
        case VKPlayerTypeUnknown:
        {
            
        }
            break;
    }
}

- (VKPlayerType)playerType
{
    switch (_videoType) {
        case VKVideoTypeNormal:
        case VKVideoTypeVR:
        {
            return VKPlayerTypeAVPlayer;
        }
        default:
        {
            return VKPlayerTypeUnknown;
        }
    }
}

- (UIView *)view
{
    if (!_view) {
        _view = [[UIView alloc] initWithFrame:CGRectZero];
        _view.backgroundColor = [UIColor blackColor];
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction)];
        [_view addGestureRecognizer:tap];
    }
    return _view;
}

- (void)tapAction
{
    if (self.playerViewTapAction) {
        VKLog(@"VKPlayer tap action");
        self.playerViewTapAction();
    }
}

- (void)setViewTapBlock:(void (^)())block
{
    self.playerViewTapAction = block;
    [self setupPlayerViewTapAction];
}

- (void)setupPlayer
{
    [self clearPlayer];
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            self.avPlayer = [VKAVPlayer playerWithURL:self.contentURL videoType:self.videoType];
            [self setupPlayerView:self.avPlayer.view];
            self.avPlayer.identifier = self.identifier;
        }
            break;
        case VKPlayerTypeUnknown:
        {
            [self playerError];
        }
            break;
    }
    if (self.playerViewTapAction) {
        [self setupPlayerViewTapAction];
    }
}

- (void)clearPlayer
{
    if (self.avPlayer) {
        [self.avPlayer stop];
        self.avPlayer = nil;
    }
    [self clearPlayerView];
}

- (void)setupPlayerView:(UIView *)playerView;
{
    [self clearPlayerView];
    [self.view addSubview:playerView];
    
    playerView.translatesAutoresizingMaskIntoConstraints = NO;
    
    NSLayoutConstraint * top = [NSLayoutConstraint constraintWithItem:playerView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTop multiplier:1 constant:0];
    NSLayoutConstraint * bottom = [NSLayoutConstraint constraintWithItem:playerView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeBottom multiplier:1 constant:0];
    NSLayoutConstraint * left = [NSLayoutConstraint constraintWithItem:playerView attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0];
    NSLayoutConstraint * right = [NSLayoutConstraint constraintWithItem:playerView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0];
    
    [self.view addConstraint:top];
    [self.view addConstraint:bottom];
    [self.view addConstraint:left];
    [self.view addConstraint:right];
}

- (void)clearPlayerView
{
    [self.view.subviews enumerateObjectsUsingBlock:^(__kindof UIView * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj removeFromSuperview];
    }];
}

- (void)setupPlayerViewTapAction
{
    switch (self.playerType) {
        case VKPlayerTypeAVPlayer:
        {
            [self.avPlayer setViewTapBlock:self.playerViewTapAction];
        }
            break;
        case VKPlayerTypeUnknown:
        {
            
        }
            break;
    }
}

- (void)playerError
{
    [self clearPlayer];
    VKLog(@"VKPlayer unsupport video type");
    [VKNotification postPlayer:self.identifier errorMessage:@"unsupport video type" code:1901];
}

@end
