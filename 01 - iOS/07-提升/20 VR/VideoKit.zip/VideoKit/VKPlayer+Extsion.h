//
//  VKPlayer+Extsion.h
//  VideoKitDemo
//
//  Created by Single on 16/8/16.
//  Copyright © 2016年 single. All rights reserved.
//

#import "VKPlayer.h"

@class VKState;
@class VKProgress;
@class VKPlayable;
@class VKError;

#pragma mark - VKPlayer Extsion Category

@interface VKPlayer (Extsion)

+ (void)registerNotificationTarget:(id)target stateAction:(SEL)stateAction progressAction:(SEL)progressAction playableAction:(SEL)playableAction;      // object's class is NSNotification
+ (void)removeNotification:(id)target;

@end

#pragma mark - Models

@interface VKModel : NSObject
@property (nonatomic, copy) NSString * identifier;
@end

@interface VKState : VKModel
@property (nonatomic, assign) VKPlayerState previous;
@property (nonatomic, assign) VKPlayerState current;
+ (VKState *)stateFromUserInfo:(NSDictionary *)userInfo;
@end

@interface VKProgress : VKModel
@property (nonatomic, assign) CGFloat percent;
@property (nonatomic, assign) CGFloat current;
@property (nonatomic, assign) CGFloat total;
+ (VKProgress *)progressFromUserInfo:(NSDictionary *)userInfo;
@end

@interface VKPlayable : VKModel
@property (nonatomic, assign) CGFloat percent;
@property (nonatomic, assign) CGFloat current;
@property (nonatomic, assign) CGFloat total;
+ (VKPlayable *)playableFromUserInfo:(NSDictionary *)userInfo;
@end

@interface VKError : VKModel
@property (nonatomic, copy) NSString * message;
@property (nonatomic, assign) NSInteger code;
+ (VKError *)errorFromUserInfo:(NSDictionary *)userInfo;
@end

