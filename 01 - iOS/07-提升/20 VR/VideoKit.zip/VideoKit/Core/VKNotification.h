//
//  VKNotification.h
//  VideoKitDemo
//
//  Created by Single on 16/8/15.
//  Copyright © 2016年 single. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "VKPlayerDefine.h"

@interface VKNotification : NSObject

+ (void)postPlayer:(NSString *)identifier errorMessage:(NSString *)message code:(NSInteger)code;
+ (void)postPlayer:(NSString *)identifier statePrevious:(VKPlayerState)previous current:(VKPlayerState)current;
+ (void)postPlayer:(NSString *)identifier progressPercent:(NSNumber *)percent current:(NSNumber *)current total:(NSNumber *)total;
+ (void)postPlayer:(NSString *)identifier playablePercent:(NSNumber *)percent current:(NSNumber *)current total:(NSNumber *)total;

@end
