//
//  VKNotification.m
//  VideoKitDemo
//
//  Created by Single on 16/8/15.
//  Copyright © 2016年 single. All rights reserved.
//

#import "VKNotification.h"

@implementation VKNotification

+ (void)postPlayer:(NSString *)identifier errorMessage:(NSString *)message code:(NSInteger)code
{
    if (![identifier isKindOfClass:[NSString class]] || identifier == nil) identifier = VKPlayerDefaultIdentifier;
    if (![message isKindOfClass:[NSString class]] || message == nil) message = @"VKPlayer unknown error";
    if (code <= 0) code = 1900;
    NSDictionary * userInfo = @{
                                VKPlayerIdentifierKey : identifier,
                                VKPlayerErrorMessageKey : message,
                                VKPlayerErrorCodeKey : @(code)
                                };
    [[NSNotificationCenter defaultCenter] postNotificationName:VKPlayerErrorName object:nil userInfo:userInfo];
}

+ (void)postPlayer:(NSString *)identifier statePrevious:(VKPlayerState)previous current:(VKPlayerState)current
{
    if (![identifier isKindOfClass:[NSString class]] || identifier == nil) identifier = VKPlayerDefaultIdentifier;
    NSDictionary * userInfo = @{
                                VKPlayerIdentifierKey : identifier,
                                VKPlayerStatePreviousKey : @(previous),
                                VKPlayerStateCurrentKey : @(current)
                                };
    [[NSNotificationCenter defaultCenter] postNotificationName:VKPlayerStateChangeName object:nil userInfo:userInfo];
}

+ (void)postPlayer:(NSString *)identifier progressPercent:(NSNumber *)percent current:(NSNumber *)current total:(NSNumber *)total
{
    if (![identifier isKindOfClass:[NSString class]] || identifier == nil) identifier = VKPlayerDefaultIdentifier;
    if (![percent isKindOfClass:[NSNumber class]]) percent = @(0);
    if (![current isKindOfClass:[NSNumber class]]) current = @(0);
    if (![total isKindOfClass:[NSNumber class]]) total = @(0);
    NSDictionary * userInfo = @{
                                VKPlayerIdentifierKey : identifier,
                                VKPlayerProgressPercentKey : percent,
                                VKPlayerProgressCurrentKey : current,
                                VKPlayerProgressTotalKey : total
                                };
    [[NSNotificationCenter defaultCenter] postNotificationName:VKPlayerProgressChangeName object:nil userInfo:userInfo];
}

+ (void)postPlayer:(NSString *)identifier playablePercent:(NSNumber *)percent current:(NSNumber *)current total:(NSNumber *)total
{
    if (![identifier isKindOfClass:[NSString class]] || identifier == nil) identifier = VKPlayerDefaultIdentifier;
    if (![percent isKindOfClass:[NSNumber class]]) percent = @(0);
    if (![current isKindOfClass:[NSNumber class]]) current = @(0);
    if (![total isKindOfClass:[NSNumber class]]) total = @(0);
    NSDictionary * userInfo = @{
                                VKPlayerIdentifierKey : identifier,
                                VKPlayerPlayablePercentKey : percent,
                                VKPlayerPlayableCurrentKey : current,
                                VKPlayerPlayableTotalKey : total,
                                };
    [[NSNotificationCenter defaultCenter] postNotificationName:VKPlayerPlayableChangeName object:nil userInfo:userInfo];
}

@end
