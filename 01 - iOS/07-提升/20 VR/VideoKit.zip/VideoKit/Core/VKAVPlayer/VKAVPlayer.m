//
//  VKAVPlayer.m
//  VideoKitDemo
//
//  Created by Single on 16/6/28.
//  Copyright © 2016年 single. All rights reserved.
//

#import "VKAVPlayer.h"
#import "VKNotification.h"
#import "VKView.h"
#import "VKGLView.h"

#define kRequestInterval 0.03

@interface VKAVPlayer () <VKGLViewDataSource>

@property (nonatomic, strong) id playBackTimeObserver;
@property (nonatomic, strong) AVPlayer * avPlayer;
@property (nonatomic, strong) AVPlayerItem * avPlayerItem;
@property (nonatomic, strong) CALayer * avPlayerLayer;
@property (nonatomic, strong) VKGLView * avGLView;
@property (nonatomic, strong) AVAsset * avAsset;
@property (nonatomic, strong) AVPlayerItemVideoOutput * avOutput;
@property (nonatomic, assign) NSTimeInterval readyToPlayTime;

@property (nonatomic, assign) BOOL needPlay;

@end

@implementation VKAVPlayer

@synthesize playableTime = _playableTime;

#pragma mark - init

+ (instancetype)playerWithURL:(NSURL *)contentURL
{
    return [[self alloc] initWithURL:contentURL videoType:VKVideoTypeNormal];
}

+ (instancetype)playerWithURL:(NSURL *)contentURL videoType:(VKVideoType)videoType
{
    return [[self alloc] initWithURL:contentURL videoType:videoType];
}

- (instancetype)initWithURL:(NSURL *)contentURL
{
    return [self initWithURL:contentURL videoType:VKVideoTypeNormal];
}

- (instancetype)initWithURL:(NSURL *)contentURL videoType:(VKVideoType)videoType
{
    if (self = [super init]) {
        self.contentURL = contentURL;
        self.videoType = videoType;
        self.playableBufferInterval = 2.f;
        [self setupPlayer];
    }
    return self;
}

- (instancetype)init
{
    if (self = [super init]) {
        self.contentURL = nil;
        self.videoType = VKVideoTypeNormal;
        self.playableBufferInterval = 2.f;
    }
    return self;
}

- (void)replaceVideoWithURL:(NSURL *)contentURL
{
    [self replaceVideoWithURL:contentURL videoType:VKVideoTypeNormal];
}

- (void)replaceVideoWithURL:(NSURL *)contentURL videoType:(VKVideoType)videoType
{
    self.contentURL = contentURL;
    self.videoType = videoType;
    [self setupPlayer];
}

#pragma mark - play control

- (void)play
{
    if (self.state == VKPlayerStateFailed || self.state == VKPlayerStateFinished) {
        [self clearPlayer];
    }
    
    switch (self.state) {
        case VKPlayerStateNone:
            self.state = VKPlayerStateBuffering;
            break;
        case VKPlayerStateSuspend:
        case VKPlayerStateReadyToPlay:
            self.state = VKPlayerStatePlaying;
        default:
            break;
    }
    
    [self trySetupPlayer];
    
    
    if (self.state != VKPlayerStatePlaying) {
        
    }
    [self.avPlayer play];
    
}

- (void)setPlayIfNeed
{
    switch (self.state) {
        case VKPlayerStatePlaying:
            self.state = VKPlayerStateBuffering;
        case VKPlayerStateBuffering:
            self.needPlay = YES;
            [self.avPlayer pause];
            break;
        default:
            break;
    }
}

- (void)cancelPlayIfNeed
{
    if (self.needPlay) {
        self.needPlay = NO;
    }
}

- (void)playIfNeed
{
    if (self.needPlay) {
        self.state = VKPlayerStatePlaying;
        [self.avPlayer play];
        self.needPlay = NO;
    }
}

- (void)pause
{
    if (self.state == VKPlayerStateFailed) return;
    self.state = VKPlayerStateSuspend;
    [self cancelPlayIfNeed];
    [self.avPlayer pause];
}

- (void)seekToTime:(NSTimeInterval)time
{
    if (self.avPlayerItem.status != AVPlayerItemStatusReadyToPlay) return;
    
    [self setPlayIfNeed];
    VKWeakSelf
    [self.avPlayerItem seekToTime:CMTimeMakeWithSeconds(time, NSEC_PER_SEC) completionHandler:^(BOOL finished) {
        [weakSelf playIfNeed];
        VKLog(@"VKAVPlayer seek success");
    }];
}

- (void)stop
{
    [self clearPlayer];
}

- (NSTimeInterval)progress
{
    return CMTimeGetSeconds(self.avPlayerItem.currentTime);
}

- (NSTimeInterval)duration
{
    return CMTimeGetSeconds(self.avPlayerItem.duration);
}

#pragma mark - Setter/Getter

- (void)setState:(VKPlayerState)state
{
    if (_state != state) {
        VKPlayerState temp = _state;
        _state = state;
        [VKNotification postPlayer:self.identifier statePrevious:temp current:_state];
    }
}

- (void)setContentURL:(NSURL *)contentURL
{
    _contentURL = contentURL;
}

- (void)setVideoType:(VKVideoType)videoType
{
    _videoType = videoType;
}

- (void)setAvPlayer:(AVPlayer *)avPlayer
{
    if (_avPlayer != avPlayer) {
        if (self.playBackTimeObserver) {
            [_avPlayer removeTimeObserver:self.playBackTimeObserver];
            self.playBackTimeObserver = nil;
        }
        _avPlayer = avPlayer;
        
        if (_avPlayer) {
            VKWeakSelf
            self.playBackTimeObserver = [_avPlayer addPeriodicTimeObserverForInterval:CMTimeMake(1, 1) queue:dispatch_get_main_queue() usingBlock:^(CMTime time) {
                if (weakSelf.state == VKPlayerStatePlaying) {
                    CGFloat current = CMTimeGetSeconds(time);
                    CGFloat duration = weakSelf.duration;
                    [VKNotification postPlayer:weakSelf.identifier progressPercent:@(current/duration) current:@(current) total:@(duration)];
                }
            }];
        }
    }
}

- (void)setAvPlayerItem:(AVPlayerItem *)avPlayerItem
{
    if (_avPlayerItem != avPlayerItem) {
        [_avPlayerItem removeObserver:self forKeyPath:@"status"];
        [_avPlayerItem removeObserver:self forKeyPath:@"playbackBufferEmpty"];
        [_avPlayerItem removeObserver:self forKeyPath:@"loadedTimeRanges"];
        [_avPlayerItem removeOutput:self.avOutput];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:_avPlayerItem];
        _avPlayerItem = avPlayerItem;
        if (_avPlayerItem) {
            [_avPlayerItem addObserver:self forKeyPath:@"status" options:0 context:NULL];
            [_avPlayerItem addObserver:self forKeyPath:@"playbackBufferEmpty" options:NSKeyValueObservingOptionNew context:NULL];
            [_avPlayerItem addObserver:self forKeyPath:@"loadedTimeRanges" options:NSKeyValueObservingOptionNew context:NULL];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(avplayerItemDidPlayToEnd:) name:AVPlayerItemDidPlayToEndTimeNotification object:_avPlayerItem];
        }
    }
}

- (void)avplayerItemDidPlayToEnd:(NSNotification *)notification
{
    self.state = VKPlayerStateFinished;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    if (object == self.avPlayerItem) {
        if ([keyPath isEqualToString:@"status"])
        {
            switch (self.avPlayerItem.status) {
                case AVPlayerItemStatusUnknown:
                {
                    self.state = VKPlayerStateBuffering;
                    VKLog(@"VKAVPlayer item status unknown");
                }
                    break;
                case AVPlayerItemStatusReadyToPlay:
                {
                    VKLog(@"VKAVPlayer item status ready to play");
                    self.readyToPlayTime = [NSDate date].timeIntervalSince1970;
                    switch (self.state) {
                        case VKPlayerStateBuffering:
                            self.state = VKPlayerStatePlaying;
                        case VKPlayerStatePlaying:
                            [self playIfNeed];
                            break;
                        case VKPlayerStateSuspend:
                        case VKPlayerStateFinished:
                        case VKPlayerStateFailed:
                            break;
                        default:
                            self.state = VKPlayerStateReadyToPlay;
                            break;
                    }
                }
                    break;
                case AVPlayerItemStatusFailed:
                {
                    VKLog(@"VKAVPlayer item status failed");
                    self.readyToPlayTime = 0;
                    self.state = VKPlayerStateFailed;
                }
                    break;
            }
        }
        else if ([keyPath isEqualToString:@"playbackBufferEmpty"])
        {
            if (self.avPlayerItem.playbackBufferEmpty) {
                [self setPlayIfNeed];
            }
        }
        else if ([keyPath isEqualToString:@"loadedTimeRanges"])
        {
            NSTimeInterval playableTime = self.playableTime;
            if (_playableTime != playableTime) {
                _playableTime = playableTime;
                CGFloat duration = self.duration;
                [VKNotification postPlayer:self.identifier playablePercent:@(playableTime/duration) current:@(playableTime) total:@(duration)];
            }
            
            if ((playableTime - self.progress) > self.playableBufferInterval) {
                [self playIfNeed];
            }
        }
    }
}

- (NSTimeInterval)playableTime
{
    if (self.avPlayerItem.status == AVPlayerItemStatusReadyToPlay) {
        CMTimeRange range = [self.avPlayerItem.loadedTimeRanges.firstObject CMTimeRangeValue];
        NSTimeInterval start = CMTimeGetSeconds(range.start);
        NSTimeInterval duration = CMTimeGetSeconds(range.duration);
        return (start + duration);
    }
    return 0;
}

- (UIView *)view
{
    if (!_view) {
        _view = [[VKView alloc] initWithFrame:CGRectZero];
    }
    return _view;
}

- (void)setViewTapBlock:(void (^)())block
{
    if ([self.view isKindOfClass:[VKView class]]) {
        ((VKView *)self.view).tapActionBlock = block;
    }
}

- (void)vk_glViewTapAction:(VKGLView *)glView
{
    if ([self.view isKindOfClass:[VKView class]]) {
        [(VKView *)self.view tapAction];
    }
}

- (CVPixelBufferRef)vk_glViewPixelBufferToDraw:(VKGLView *)glView
{
    CVPixelBufferRef pixelBuffer = [self.avOutput copyPixelBufferForItemTime:self.avPlayerItem.currentTime itemTimeForDisplay:nil];
    if (!pixelBuffer) {
        BOOL isReadyToPlay = self.avPlayerItem.status == AVPlayerStatusReadyToPlay && self.readyToPlayTime > 10 && (([NSDate date].timeIntervalSince1970 - self.readyToPlayTime) > 0.3);
        if (isReadyToPlay) {
            [self setupOutput];
        }
    }
    return pixelBuffer;
}

- (void)trySetupPlayer
{
    if (!self.avPlayer) {
        [self setupPlayer];
    }
}

- (void)setupPlayer
{
    [self clearPlayer];
    switch (self.videoType) {
        case VKVideoTypeNormal:
        {
            self.avPlayerItem = [AVPlayerItem playerItemWithURL:self.contentURL];
            self.avPlayer = [AVPlayer playerWithPlayerItem:self.avPlayerItem];
            self.avPlayerLayer = [AVPlayerLayer playerLayerWithPlayer:self.avPlayer];
            ((VKView *)self.view).graphicsLayer = self.avPlayerLayer;
        }
            break;
        case VKVideoTypeVR:
        {
            self.avAsset = [AVAsset assetWithURL:self.contentURL];
            self.avPlayerItem = [AVPlayerItem playerItemWithAsset:self.avAsset];
            self.avPlayer = [AVPlayer playerWithPlayerItem:self.avPlayerItem];
            self.avGLView = [[VKGLView alloc] initWithFrame:CGRectZero];
            self.avGLView.dataSource = self;
            self.avPlayerLayer = self.avGLView.layer;
            ((VKView *)self.view).graphicsLayer = self.avPlayerLayer;
            VKWeakSelf
            [self.avAsset loadValuesAsynchronouslyForKeys:[self avAssetloadKeys] completionHandler:^{
                dispatch_async(dispatch_get_main_queue(), ^{
                    for (NSString * loadKey in [weakSelf avAssetloadKeys]) {
                        NSError * error = nil;
                        AVKeyValueStatus keyStatus = [weakSelf.avAsset statusOfValueForKey:loadKey error:&error];
                        if (keyStatus == AVKeyValueStatusFailed) {
                            [weakSelf avAssetPrepareFailed:error];
                            VKLog(@"AVAsset load failed");
                            return;
                        }
                    }
                    NSError * error = nil;
                    AVKeyValueStatus trackStatus = [weakSelf.avAsset statusOfValueForKey:@"tracks" error:&error];
                    if (trackStatus == AVKeyValueStatusLoaded) {
                        [weakSelf setupOutput];
                    } else {
                        VKLog(@"AVAsset load failed");
                    }
                });
            }];
        }
            break;
    }
}

- (void)setupOutput
{
    [self clearOutput];
    
    NSDictionary * pixelBuffer = @{(id)kCVPixelBufferPixelFormatTypeKey: @(kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange)};
    self.avOutput = [[AVPlayerItemVideoOutput alloc] initWithPixelBufferAttributes:pixelBuffer];
    [self.avOutput requestNotificationOfMediaDataChangeWithAdvanceInterval:kRequestInterval];
    [self.avPlayerItem addOutput:self.avOutput];
    
    VKLog(@"VKAVPlayer add output success");
}


- (void)avAssetPrepareFailed:(NSError *)error
{
    
}

- (void)clearPlayer
{
    [VKNotification postPlayer:self.identifier playablePercent:@(0) current:@(0) total:@(0)];
    [VKNotification postPlayer:self.identifier progressPercent:@(0) current:@(0) total:@(0)];
    [self clearOutput];
    self.avPlayer = nil;
    self.avPlayerItem = nil;
    self.avPlayerLayer = nil;
    self.avAsset = nil;
    ((VKView *)self.view).graphicsLayer = nil;
    [self.avGLView invalidate];
    self.avGLView = nil;
    self.playBackTimeObserver = nil;
    self.state = VKPlayerStateNone;
    self.needPlay = NO;
    _playableTime = 0;
    self.readyToPlayTime = 0;
}

- (void)clearOutput
{
    if (self.avPlayerItem) {
        [self.avPlayerItem removeOutput:self.avOutput];
    }
    self.avOutput = nil;
}

- (NSArray <NSString *> *)avAssetloadKeys
{
    return @[@"tracks", @"playable"];
}

- (void)dealloc
{
    VKLog(@"VKAVPlayer release");
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self clearPlayer];
}

@end
