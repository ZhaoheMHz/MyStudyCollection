//
//  VKGLMatrix.m
//  VideoKitDemo
//
//  Created by Single on 16/7/26.
//  Copyright © 2016年 single. All rights reserved.
//

#import "VKGLMatrix.h"
#include "VKGLVariable.h"
#import "VKGLSensors.h"
#import "VKPlayerMacro.h"

@interface VKGLMatrix ()

@property (nonatomic, strong) VKGLSensors * sensors;

@end

@implementation VKGLMatrix

- (instancetype)init
{
    if (self = [super init]) {
        
        [self setupSensors];
    }
    return self;
}

#pragma mark - sensors

- (void)setupSensors
{
    self.sensors = [[VKGLSensors alloc] init];
    [self.sensors start];
}

- (GLKMatrix4)matrixWithSize:(CGSize)size
{
    if (!self.sensors.isReady) return GLKMatrix4Make(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    
    GLKMatrix4 modelViewMatrix = GLKMatrix4Identity;
    modelViewMatrix = GLKMatrix4RotateX(modelViewMatrix, -self.fingerRotationX);
    modelViewMatrix = GLKMatrix4Multiply(modelViewMatrix, self.sensors.modelView);
    modelViewMatrix = GLKMatrix4RotateY(modelViewMatrix, self.fingerRotationY);
    
    float aspect = fabs(size.width / size.height);
    GLKMatrix4 mvpMatrix = GLKMatrix4Identity;
    GLKMatrix4 projectionMatrix = GLKMatrix4MakePerspective(GLKMathDegreesToRadians(default_degrees), aspect, 0.1f, 400.0f);
    GLKMatrix4 viewMatrix = GLKMatrix4MakeLookAt(0, 0, 0.3, 0, 0, -1000, 0, 1, 0);
    mvpMatrix = GLKMatrix4Multiply(projectionMatrix, viewMatrix);
    mvpMatrix = GLKMatrix4Multiply(mvpMatrix, modelViewMatrix);
    
    self.matrix = mvpMatrix;
    return self.matrix;
}

- (void)dealloc
{
    VKLog(@"VKGLMatrix release");
    [self.sensors stop];
}

@end
