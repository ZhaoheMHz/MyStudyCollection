//
//  VKGLMatrix.h
//  VideoKitDemo
//
//  Created by Single on 16/7/26.
//  Copyright © 2016年 single. All rights reserved.
//

#import <GLKit/GLKit.h>
#import <CoreMotion/CoreMotion.h>

@interface VKGLMatrix : NSObject

@property (assign, nonatomic) CGFloat fingerRotationX;
@property (assign, nonatomic) CGFloat fingerRotationY;
@property (assign, nonatomic) GLKMatrix4 matrix;

- (GLKMatrix4)matrixWithSize:(CGSize)size;

@end
