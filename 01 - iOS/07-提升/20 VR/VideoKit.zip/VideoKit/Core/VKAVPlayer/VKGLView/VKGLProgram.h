//
//  VKGLProgram.h
//  VideoKitDemo
//
//  Created by Single on 16/7/25.
//  Copyright © 2016年 single. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>

@interface VKGLProgram : NSObject

@property (nonatomic, strong) NSMutableArray * attributes;
@property (nonatomic, strong) NSMutableArray * uniforms;
@property (nonatomic, assign) GLuint program;
@property (nonatomic, assign) GLuint vertexShader;
@property (nonatomic, assign) GLuint fragmentShader;

- (instancetype)initWithVertexShader:(NSString *)vshfileName fragmentShader:(NSString *)fshFileName;

- (void)addAttribute:(NSString *)attributeName;
- (GLuint)attributeIndex:(NSString *)attributeName;
- (GLuint)uniformIndex:(NSString *)uniformName;
- (BOOL)link;
- (void)use;

@end
