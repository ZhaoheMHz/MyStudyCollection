//
//  VKGLView.m
//  HTY360Player
//
//  Created by Single on 16/7/25.
//  Copyright © 2016年 Hanton. All rights reserved.
//

#import "VKGLView.h"
#import "VKPlayerMacro.h"
#import "VKGLProgram.h"
#import "VKGLVariable.h"
#import "VKGLMatrix.h"
#import "VKGLTexture.h"

@interface VKGLView () <GLKViewDelegate>

@property (nonatomic, assign) BOOL hasInit;

@property (nonatomic, strong) CADisplayLink * displayLink;

@property (nonatomic, strong) VKGLProgram * program;
@property (nonatomic, strong) VKGLVariable * variable;
@property (nonatomic, strong) VKGLMatrix * matrix;
@property (nonatomic, strong) VKGLTexture * texture;

@end

@implementation VKGLView

#pragma mark - 初始化

- (void)tryInit
{
    if (!self.hasInit) {
        [self setup];
        self.hasInit = YES;
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    [self tryInit];
}

#pragma mark - Setup

- (void)setup
{
    [self setupGL];
    [self setupDisplayLink];
    [self setupGesture];
}

#pragma mark - Setup OpenGL

// 设置OpenGL
- (void)setupGL
{
    [self setupGLKView];
    [self setupGLProgram];
    [self setupGLBuffers];
    [self setupGLUniform];
}

// GLKView
- (void)setupGLKView
{
    self.drawableDepthFormat = GLKViewDrawableDepthFormat24;
    self.contentScaleFactor = [UIScreen mainScreen].scale;
    self.delegate = self;
    self.context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    [EAGLContext setCurrentContext:self.context];
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
}

// Program
- (void)setupGLProgram
{
    self.program = [[VKGLProgram alloc] initWithVertexShader:@"Shader" fragmentShader:@"Shader"];
    [self.program addAttribute:@"position"];
    [self.program addAttribute:@"texCoord"];
    
    if (![self.program link]) {
        self.program = nil;
        VKLog(@"Program link failure");
    }
    
    self.variable.vertexTexCoordAttributeIndex = [self.program attributeIndex:@"texCoord"];
    
    self.variable.uniform_model_view_projection_matrix = [self.program uniformIndex:@"modelViewProjectionMatrix"];
    self.variable.uniform_y = [self.program uniformIndex:@"SamplerY"];
    self.variable.uniform_uv = [self.program uniformIndex:@"SamplerUV"];
    self.variable.uniform_color_conversion_martrix = [self.program uniformIndex:@"colorConversionMatrix"];
    
    [self.program use];
}

// buffers
- (void)setupGLBuffers
{
    GLfloat * vVertices = NULL;
    GLfloat * vTextCoord = NULL;
    GLushort * indices = NULL;
    int numVertices = 0;
    self.variable.numIndices = esGenSphere(SphereSliceNum, SphereRadius, &vVertices, &vTextCoord, &indices, &numVertices);
    
    // Indices
    GLuint vertexIndicesBufferID;
    glGenBuffers(1, &vertexIndicesBufferID);
    self.variable.vertexIndicesBufferID = vertexIndicesBufferID;
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, self.variable.vertexIndicesBufferID);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, self.variable.numIndices*sizeof(GLushort), indices, GL_STATIC_DRAW);
    
    // Vertex
    GLuint vertexBufferID;
    glGenBuffers(1, &vertexBufferID);
    self.variable.vertexBufferID = vertexBufferID;
    glBindBuffer(GL_ARRAY_BUFFER, self.variable.vertexBufferID);
    glBufferData(GL_ARRAY_BUFFER, numVertices*3*sizeof(GLfloat), vVertices, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(GLKVertexAttribPosition);
    glVertexAttribPointer(GLKVertexAttribPosition, 3, GL_FLOAT, GL_FALSE, sizeof(GLfloat)*3, NULL);
    
    // Texture Coordinates
    GLuint vertexTexCoordID;
    glGenBuffers(1, &vertexTexCoordID);
    self.variable.vertexTexCoordID = vertexTexCoordID;
    glBindBuffer(GL_ARRAY_BUFFER, self.variable.vertexTexCoordID);
    glBufferData(GL_ARRAY_BUFFER, numVertices*2*sizeof(GLfloat), vTextCoord, GL_DYNAMIC_DRAW);
    
    glEnableVertexAttribArray(self.variable.vertexTexCoordAttributeIndex);
    glVertexAttribPointer(self.variable.vertexTexCoordAttributeIndex, 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat)*2, NULL);
}

// buffers
- (void)setupGLUniform
{
    glUniform1i(self.variable.uniform_y, 0);
    glUniform1i(self.variable.uniform_uv, 1);
    glUniformMatrix3fv(self.variable.uniform_color_conversion_martrix, 1, GL_FALSE, self.variable.colorConversion709);
}

#pragma mark - Setup Other

- (void)setupGesture
{
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureAction:)];
    [self addGestureRecognizer:tap];
}

- (void)tapGestureAction:(UITapGestureRecognizer *)tap
{
    VKLog(@"VKGLView tap action");
    if ([self.dataSource respondsToSelector:@selector(vk_glViewTapAction:)]) {
        [self.dataSource vk_glViewTapAction:self];
    }
}

- (void)setupDisplayLink
{
    self.displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(displayLinkAction)];
    [self.displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSDefaultRunLoopMode];
    self.displayLink.paused = NO;
}

#pragma mark - OpenGL draw

- (void)displayLinkAction
{
    if ([UIApplication sharedApplication].applicationState == UIApplicationStateActive) {
        [self display];
        [self updateJFrame];
    }
}

// update frame
- (void)updateJFrame
{
//    VKLog(@"update");
    GLKMatrix4 viewMatrix = [self.matrix matrixWithSize:self.bounds.size];
    glUniformMatrix4fv(self.variable.uniform_model_view_projection_matrix, 1, GL_FALSE, viewMatrix.m);
}

// draw GLKView
- (void)glkView:(GLKView *)view drawInRect:(CGRect)rect
{
//    VKLog(@"draw");
    glClear(GL_COLOR_BUFFER_BIT);
    CVPixelBufferRef pixelBuffer = [self.dataSource vk_glViewPixelBufferToDraw:self];
    if (!pixelBuffer && !self.texture.hasTexture) return;
    [self.texture refreshTextureWithPixelBuffer:pixelBuffer];
    glDrawElements(GL_TRIANGLES, self.variable.numIndices, GL_UNSIGNED_SHORT, 0);
}

#pragma mark - 手势响应

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch * touch = [touches anyObject];
    float distX = [touch locationInView:touch.view].x - [touch previousLocationInView:touch.view].x;
    float distY = [touch locationInView:touch.view].y - [touch previousLocationInView:touch.view].y;
    distX *= 0.005;
    distY *= 0.005;
    self.matrix.fingerRotationX += distY *  default_degrees / 100;
    self.matrix.fingerRotationY -= distX *  default_degrees / 100;
}

#pragma mark - Setter/Getter

- (void)setPaused:(BOOL)paused
{
    self.displayLink.paused = paused;
}

- (BOOL)paused
{
    return self.displayLink.paused;
}

- (VKGLVariable *)variable
{
    if (!_variable) {
        _variable = [[VKGLVariable alloc] init];
    }
    return _variable;
}

- (VKGLMatrix *)matrix
{
    if (!_matrix) {
        _matrix = [[VKGLMatrix alloc] init];
    }
    return _matrix;
}

- (VKGLTexture *)texture
{
    if (!_texture) {
        _texture = [[VKGLTexture alloc] initWithContext:self.context];
    }
    return _texture;
}

#pragma mark - release

- (void)dealloc
{
    VKLog(@"VKGLView release");
    [self clearGL];
    
    if ([EAGLContext currentContext] == self.context) {
        [EAGLContext setCurrentContext:nil];
    }
}

- (void)removeFromSuperview
{
    [self invalidate];
    [super removeFromSuperview];
}

- (void)invalidate
{
    [self.displayLink invalidate];
}

- (void)clearGL
{
    [EAGLContext setCurrentContext:self.context];
    
    GLuint vertexIndicesBufferID = self.variable.vertexIndicesBufferID;
    GLuint vertexBufferID = self.variable.vertexBufferID;
    GLuint vertexTexCoordID = self.variable.vertexTexCoordID;
    glDeleteBuffers(1, &vertexIndicesBufferID);
    glDeleteBuffers(1, &vertexBufferID);
    glDeleteBuffers(1, &vertexTexCoordID);
    self.variable.vertexIndicesBufferID = 0;
    self.variable.vertexBufferID = 0;
    self.variable.vertexTexCoordID = 0;
    
    self.program = nil;
}

@end
