//
//  VKGLTexture.h
//  VideoKitDemo
//
//  Created by Single on 16/7/26.
//  Copyright © 2016年 single. All rights reserved.
//

#import <GLKit/GLKit.h>

@interface VKGLTexture : NSObject

- (instancetype)initWithContext:(EAGLContext *)context;

@property (nonatomic, assign, readonly) BOOL hasTexture;
@property (nonatomic, assign) CVOpenGLESTextureRef lumaTexture;
@property (nonatomic, assign) CVOpenGLESTextureRef chromaTexture;
@property (nonatomic, assign) CVOpenGLESTextureCacheRef videoTextureCache;

- (void)refreshTextureWithPixelBuffer:(CVPixelBufferRef)pixelBuffer;

@end
