//
//  VKGLProgram.m
//  VideoKitDemo
//
//  Created by Single on 16/7/25.
//  Copyright © 2016年 single. All rights reserved.
//

#import "VKGLProgram.h"
#import "VKPlayerMacro.h"

@implementation VKGLProgram

- (instancetype)initWithVertexShader:(NSString *)vshfileName fragmentShader:(NSString *)fshFileName
{
    // VSH
    NSString * vshPath = [[NSBundle mainBundle] pathForResource:vshfileName ofType:@"vsh"];
    NSString * vshString = [NSString stringWithContentsOfFile:vshPath encoding:NSUTF8StringEncoding error:nil];
    
    // FSH
    NSString * fshPath = [[NSBundle mainBundle] pathForResource:fshFileName ofType:@"fsh"];
    NSString * fshString = [NSString stringWithContentsOfFile:fshPath encoding:NSUTF8StringEncoding error:nil];
    
    return [self initWithVertexShaderString:vshString fragmentShader:fshString];
}

- (instancetype)initWithVertexShaderString:(NSString *)vshString fragmentShader:(NSString *)fshString
{
    if (self = [super init]) {
        
        self.attributes = [[NSMutableArray alloc] init];
        self.uniforms = [[NSMutableArray alloc] init];
        self.program = glCreateProgram();
        
        if (![self compileShader:&_vertexShader type:GL_VERTEX_SHADER string:vshString]) VKLog(@"load vertex shader failure");
        if (![self compileShader:&_fragmentShader type:GL_FRAGMENT_SHADER string:fshString]) VKLog(@"load fragment shader failure");
        
        glAttachShader(_program, _vertexShader);
        glAttachShader(_program, _fragmentShader);
    }
    return self;
}

- (void)addAttribute:(NSString *)attributeName
{
    if ([self.attributes containsObject:attributeName]) return;
    
    [self.attributes addObject:attributeName];
    glBindAttribLocation(self.program, (GLuint)[self.attributes indexOfObject:attributeName], [attributeName UTF8String]);
}

- (GLuint)attributeIndex:(NSString *)attributeName
{
    return (GLuint)[self.attributes indexOfObject:attributeName];
}

- (GLuint)uniformIndex:(NSString *)uniformName
{
    return glGetUniformLocation(self.program, [uniformName UTF8String]);
}

- (BOOL)link
{
    GLint status;
    glLinkProgram(self.program);
    
    glGetProgramiv(self.program, GL_LINK_STATUS, &status);
    if (status == GL_FALSE)
        return NO;
    
    if (self.vertexShader) {
        glDeleteShader(self.vertexShader);
        self.vertexShader = 0;
    }
    if (self.fragmentShader) {
        glDeleteShader(self.fragmentShader);
        self.fragmentShader = 0;
    }
    
    return YES;
}

- (void)use
{
    glUseProgram(self.program);
}

- (void)dealloc
{
    VKLog(@"VKGLProgram release");
    
    if (self.vertexShader) {
        glDeleteShader(self.vertexShader);
    }
    
    if (self.fragmentShader) {
        glDeleteShader(self.fragmentShader);
    }
    
    if (self.program) {
        glDeleteProgram(self.program);
        self.program = 0;
    }
}

#pragma mark - tool

- (BOOL)compileShader:(GLuint *)shader type:(GLenum)type string:(NSString *)shaderString {
    GLint status;
    const GLchar *source;
    
    source = (GLchar *)[shaderString UTF8String];
    if (!source) {
        VKLog(@"Failed to load shader: %@", shaderString);
        return NO;
    }
    
    *shader = glCreateShader(type);
    glShaderSource(*shader, 1, &source, NULL);
    glCompileShader(*shader);
    
    glGetShaderiv(*shader, GL_COMPILE_STATUS, &status);
    
    if (status != GL_TRUE) {
        GLint logLength;
        glGetShaderiv(*shader, GL_INFO_LOG_LENGTH, &logLength);
        if (logLength > 0) {
            GLchar *log = (GLchar *)malloc(logLength);
            glGetShaderInfoLog(*shader, logLength, &logLength, log);
            VKLog(@"Shader compile log:\n%s", log);
            free(log);
        }
    }
    
    return status == GL_TRUE;
}

@end
