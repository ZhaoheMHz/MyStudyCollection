//
//  VKGLVariable.h
//  HTY360Player
//
//  Created by Single on 16/7/25.
//  Copyright © 2016年 Hanton. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>

#define default_degrees 60.0
#define MAX_OVERTURE 95.0
#define MIN_OVERTURE 25.0
#define DEFAULT_OVERTURE 85.0
#define ES_PI  (3.14159265f)
#define ROLL_CORRECTION ES_PI/2.0
#define FramesPerSecond 30
#define SphereSliceNum 200
#define SphereRadius 1.0
#define SphereScale 300

@interface VKGLVariable : NSObject

@property (nonatomic, assign) int numIndices;

@property (nonatomic, assign) GLuint vertexIndicesBufferID;
@property (nonatomic, assign) GLuint vertexBufferID;
@property (nonatomic, assign) GLuint vertexTexCoordID;

// program
@property (nonatomic, assign) GLuint vertexTexCoordAttributeIndex;
@property (nonatomic, assign) GLuint uniform_model_view_projection_matrix;
@property (nonatomic, assign) GLuint uniform_y;
@property (nonatomic, assign) GLuint uniform_uv;
@property (nonatomic, assign) GLuint uniform_color_conversion_martrix;

@property (nonatomic, assign, readonly) GLfloat * colorConversion709;

int esGenSphere(int numSlices, float radius, float **vertices, float **texCoords, uint16_t **indices, int *numVertices_out);

@end
