//
//  VKGLView.h
//  HTY360Player
//
//  Created by Single on 16/7/25.
//  Copyright © 2016年 Hanton. All rights reserved.
//

#import <GLKit/GLKit.h>

@class VKGLView;

@protocol VKGLViewDataSource <NSObject>

- (CVPixelBufferRef)vk_glViewPixelBufferToDraw:(VKGLView *)glView;
- (void)vk_glViewTapAction:(VKGLView *)glView;

@end

@interface VKGLView : GLKView

@property (nonatomic, assign) BOOL paused;
@property (nonatomic, weak) id <VKGLViewDataSource> dataSource;

- (void)invalidate;

@end