//
//  VKView.h
//  VideoKitDemo
//
//  Created by Single on 16/6/29.
//  Copyright © 2016年 single. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VKView : UIView

@property (nonatomic, strong) CALayer * graphicsLayer;
@property (nonatomic, copy) void(^tapActionBlock)();

- (void)tapAction;

@end
