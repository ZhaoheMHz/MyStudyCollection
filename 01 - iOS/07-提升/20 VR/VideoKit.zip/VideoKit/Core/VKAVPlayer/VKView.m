//
//  VKView.m
//  VideoKitDemo
//
//  Created by Single on 16/6/29.
//  Copyright © 2016年 single. All rights reserved.
//

#import "VKView.h"
#import "VKPlayerMacro.h"

@implementation VKView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction)];
        [self addGestureRecognizer:tap];
    }
    return self;
}

- (void)tapAction
{
    if (self.tapActionBlock) {
        VKLog(@"VKView tap action");
        self.tapActionBlock();
    }
}

- (void)layoutSublayersOfLayer:(CALayer *)layer
{
    CGSize size = layer.bounds.size;
    if (size.width < size.height) {
        self.graphicsLayer.frame = CGRectMake(0, (size.height-size.width/16*9)/2, size.width, size.width/16*9);
    } else {
        self.graphicsLayer.frame = layer.bounds;
    }
}

- (void)setGraphicsLayer:(CALayer *)graphicsLayer
{
    if (_graphicsLayer != graphicsLayer) {
        [_graphicsLayer removeFromSuperlayer];
        _graphicsLayer = graphicsLayer;
        [self.layer addSublayer:graphicsLayer];
    }
}

- (void)dealloc
{
    VKLog(@"VKView release");
}

@end
