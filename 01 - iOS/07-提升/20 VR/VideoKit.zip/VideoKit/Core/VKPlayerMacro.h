//
//  VKPlayerMacro.h
//  VideoKitDemo
//
//  Created by Single on 16/6/29.
//  Copyright © 2016年 single. All rights reserved.
//

#import <Foundation/Foundation.h>

// weak self
#define VKWeakSelf __weak typeof(self) weakSelf = self;

// log level
#ifdef DEBUG
#define VKLog(...) NSLog(__VA_ARGS__)
#else
#define VKLog(...)
#endif

