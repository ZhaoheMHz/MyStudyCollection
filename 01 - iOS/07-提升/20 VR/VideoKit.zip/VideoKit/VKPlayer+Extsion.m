//
//  VKPlayer+Extsion.m
//  VideoKitDemo
//
//  Created by Single on 16/8/16.
//  Copyright © 2016年 single. All rights reserved.
//

#import "VKPlayer+Extsion.h"

@implementation VKPlayer (Extsion)

+ (void)registerNotificationTarget:(id)target stateAction:(SEL)stateAction progressAction:(SEL)progressAction playableAction:(SEL)playableAction
{
    [self registerNotificationTarget:target stateAction:stateAction progressAction:progressAction playableAction:playableAction errorAction:nil];
}

+ (void)registerNotificationTarget:(id)target stateAction:(SEL)stateAction progressAction:(SEL)progressAction playableAction:(SEL)playableAction errorAction:(SEL)errorAction
{
    if (!target) return;
    [self removeNotification:target];
    if (stateAction) [[NSNotificationCenter defaultCenter] addObserver:target selector:stateAction name:VKPlayerStateChangeName object:nil];
    if (progressAction) [[NSNotificationCenter defaultCenter] addObserver:target selector:progressAction name:VKPlayerProgressChangeName object:nil];
    if (playableAction) [[NSNotificationCenter defaultCenter] addObserver:target selector:playableAction name:VKPlayerPlayableChangeName object:nil];
    if (errorAction) [[NSNotificationCenter defaultCenter] addObserver:target selector:errorAction name:VKPlayerErrorName object:nil];
}

+ (void)removeNotification:(id)target
{
    [[NSNotificationCenter defaultCenter] removeObserver:target name:VKPlayerStateChangeName object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:target name:VKPlayerProgressChangeName object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:target name:VKPlayerPlayableChangeName object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:target name:VKPlayerErrorName object:nil];
}

@end

@implementation VKModel

@end

@implementation VKState

+ (VKState *)stateFromUserInfo:(NSDictionary *)userInfo
{
    VKState * state = [[VKState alloc] init];
    state.identifier = [userInfo objectForKey:VKPlayerIdentifierKey];
    state.previous = [[userInfo objectForKey:VKPlayerStatePreviousKey] integerValue];
    state.current = [[userInfo objectForKey:VKPlayerStateCurrentKey] integerValue];
    return state;
}

@end

@implementation VKProgress

+ (VKProgress *)progressFromUserInfo:(NSDictionary *)userInfo
{
    VKProgress * progress = [[VKProgress alloc] init];
    progress.identifier = [userInfo objectForKey:VKPlayerIdentifierKey];
    progress.percent = [[userInfo objectForKey:VKPlayerProgressPercentKey] doubleValue];
    progress.current = [[userInfo objectForKey:VKPlayerProgressCurrentKey] doubleValue];
    progress.total = [[userInfo objectForKey:VKPlayerProgressTotalKey] doubleValue];
    return progress;
}

@end

@implementation VKPlayable

+ (VKPlayable *)playableFromUserInfo:(NSDictionary *)userInfo
{
    VKPlayable * playable = [[VKPlayable alloc] init];
    playable.identifier = [userInfo objectForKey:VKPlayerIdentifierKey];
    playable.percent = [[userInfo objectForKey:VKPlayerPlayablePercentKey] doubleValue];
    playable.current = [[userInfo objectForKey:VKPlayerPlayableCurrentKey] doubleValue];
    playable.total = [[userInfo objectForKey:VKPlayerPlayableTotalKey] doubleValue];
    return playable;
}

@end

@implementation VKError

+ (VKError *)errorFromUserInfo:(NSDictionary *)userInfo
{
    VKError * error = [[VKError alloc] init];
    error.identifier = [userInfo objectForKey:VKPlayerIdentifierKey];
    error.message = [userInfo objectForKey:VKPlayerErrorMessageKey];
    error.code = [[userInfo objectForKey:VKPlayerErrorCodeKey] integerValue];
    return error;
}

@end