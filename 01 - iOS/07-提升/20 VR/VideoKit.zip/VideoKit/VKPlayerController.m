//
//  VKPlayerController.m
//  VideoKitDemo
//
//  Created by Single on 16/7/28.
//  Copyright © 2016年 single. All rights reserved.
//

#import "VKPlayerController.h"
#import "VKPlayerMacro.h"

@interface VKPlayerController ()

@property (nonatomic, strong) VKPlayer * player;

@property (nonatomic, copy) NSURL * contentUrl;
@property (nonatomic, assign) VKVideoType videoType;

@property (weak, nonatomic) IBOutlet UIView *controlView;
@property (weak, nonatomic) IBOutlet UISlider *slider;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *playStateLabel;
@property (nonatomic, assign) BOOL touching;
@property (nonatomic, assign) BOOL needHideControlView;

@end

@implementation VKPlayerController

#pragma mark - 初始化

+ (instancetype)playerControllerWithTitle:(NSString *)title contentUrl:(NSURL *)contentUrl videoType:(VKVideoType)videoType
{
    return [[self alloc] initWithTitle:title contentUrl:contentUrl videoType:videoType];
}

- (instancetype)initWithTitle:(NSString *)title contentUrl:(NSURL *)contentUrl videoType:(VKVideoType)videoType
{
    if (self = [super init]) {
        self.title = title;
        self.contentUrl = contentUrl;
        self.videoType = videoType;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self UILayout];
    
    [self setupPlayer];
    [self setHideControlViewIfNeed];
}

- (void)UILayout
{
    self.titleLabel.text = self.title;
    self.titleLabel.adjustsFontSizeToFitWidth = YES;
    
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapControlView)];
    [self.controlView addGestureRecognizer:tap];
}

- (void)setupPlayer
{
    self.player = [VKPlayer playerWithURL:self.contentUrl videoType:self.videoType];
    
    VKWeakSelf
    [self.player setViewTapBlock:^{
        [weakSelf showControlView:YES];
    }];
    
    [self.view insertSubview:self.player.view atIndex:0];
    self.player.view.translatesAutoresizingMaskIntoConstraints = NO;
    
    NSLayoutConstraint * top = [NSLayoutConstraint constraintWithItem:self.player.view attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeTop multiplier:1 constant:0];
    NSLayoutConstraint * bottom = [NSLayoutConstraint constraintWithItem:self.player.view attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeBottom multiplier:1 constant:0];
    NSLayoutConstraint * left = [NSLayoutConstraint constraintWithItem:self.player.view attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeLeft multiplier:1 constant:0];
    NSLayoutConstraint * right = [NSLayoutConstraint constraintWithItem:self.player.view attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeRight multiplier:1 constant:0];
    
    [self.view addConstraint:top];
    [self.view addConstraint:bottom];
    [self.view addConstraint:left];
    [self.view addConstraint:right];
    
    [VKPlayer registerNotificationTarget:self
                             stateAction:@selector(playerStateChange:)
                          progressAction:@selector(playerProgressChange:)
                          playableAction:@selector(playerPlayableChange:)];
}

#pragma mark - VKPlayer通知

- (void)playerStateChange:(NSNotification *)notification
{
    VKState * state = [VKState stateFromUserInfo:notification.userInfo];
    switch (state.current) {
        case VKPlayerStateNone:
            self.playStateLabel.text = @"None";
            break;
        case VKPlayerStateBuffering:
            self.playStateLabel.text = @"Buffering";
            break;
        case VKPlayerStateReadyToPlay:
            self.playStateLabel.text = @"Ready";
            break;
        case VKPlayerStatePlaying:
            self.playStateLabel.text = @"Playing";
            break;
        case VKPlayerStateSuspend:
            self.playStateLabel.text = @"Suspend";
            break;
        case VKPlayerStateFinished:
            self.playStateLabel.text = @"Finished";
            break;
        case VKPlayerStateFailed:
            self.playStateLabel.text = @"Failed";
            break;
    }
}

- (void)playerProgressChange:(NSNotification *)notification
{
    if (self.touching) return;
    VKProgress * progress = [VKProgress progressFromUserInfo:notification.userInfo];
    self.slider.value = progress.percent;
}

- (void)playerPlayableChange:(NSNotification *)notification
{
    VKPlayable * playable = [VKPlayable playableFromUserInfo:notification.userInfo];
    VKLog(@"VKPlayerController buffer progress : %f", playable.percent);
}

- (void)playerError:(NSNotification *)notification
{
    VKError * error = [VKError errorFromUserInfo:notification.userInfo];
    VKLog(@"VKPlayerController player did error \nmessage : %@", error.message);
}

#pragma mark - 播放控制

- (IBAction)sliderValueChange
{
    self.touching = YES;
}

- (IBAction)sliderTouchUp
{
    self.touching = NO;
    [self.player seekToTime:self.player.duration * self.slider.value];
}

- (IBAction)backAction
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)playAndPauseAction:(UIButton *)button
{
    button.selected = !button.selected;
    if (button.selected) {
        [self.player play];
    } else {
        [self.player pause];
    }
}

- (void)showControlView:(BOOL)animated
{
    if (animated) {
        self.controlView.hidden = NO;
        self.controlView.alpha = 0;
        [UIView animateWithDuration:0.2 animations:^{
            self.controlView.alpha = 1;
        } completion:^(BOOL finished) {
            [self setHideControlViewIfNeed];
        }];
    } else {
        self.controlView.hidden = NO;
        self.controlView.alpha = 1;
        [self setHideControlViewIfNeed];
    }
}

- (void)hideControlView:(BOOL)animated
{
    if (animated) {
        [UIView animateWithDuration:0.2 animations:^{
            self.controlView.alpha = 0;
        } completion:^(BOOL finished) {
            self.controlView.hidden = YES;
        }];
    } else {
        self.controlView.hidden = YES;
    }
}

- (void)tapControlView
{
    self.needHideControlView = NO;
    [self hideControlView:YES];
}

- (void)setHideControlViewIfNeed
{
    // cancel auto hide
//    self.needHideControlView = YES;
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        if (self.needHideControlView) {
//            self.needHideControlView = NO;
//            [self hideControlView:YES];
//        }
//    });
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)dealloc
{
    VKLog(@"VKPlayerController release");
    [VKPlayer removeNotification:self];
}

@end

@implementation UIViewController (VKPlayerExtsion)

- (void)vk_presentVKPlayerController:(VKPlayerController *)playerController
{
    if ([playerController isKindOfClass:[VKPlayerController class]]) {
        [self presentViewController:playerController animated:YES completion:nil];
    }
}

@end
