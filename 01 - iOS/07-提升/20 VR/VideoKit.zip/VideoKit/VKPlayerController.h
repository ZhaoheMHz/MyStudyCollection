//
//  VKPlayerController.h
//  VideoKitDemo
//
//  Created by Single on 16/7/28.
//  Copyright © 2016年 single. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VKPlayer.h"

@interface VKPlayerController : UIViewController

+ (instancetype)playerControllerWithTitle:(NSString *)title contentUrl:(NSURL *)contentUrl videoType:(VKVideoType)videoType;

@end

@interface UIViewController (VKPlayerExtsion)

- (void)vk_presentVKPlayerController:(VKPlayerController *)playerController;

@end